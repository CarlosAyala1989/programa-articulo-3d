"""Servicio físico separado: sus dependencias no cambian los runtimes CAD congelados."""
import os
from pathlib import Path
from uuid import UUID

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from evaluador.metrologia import procesar_carpeta

aplicacion = FastAPI(title='Metrología física Agente Ciel', version='1.0.0')
RAIZ = Path(os.environ.get('DIRECTORIO_ARTEFACTOS', '/datos'))


class SolicitudMetrologia(BaseModel):
    comparacion_identificador: UUID


@aplicacion.get('/salud')
def salud() -> dict:
    return {'estado': 'disponible', 'protocolo': 'ciel-metrologia-otter-v1'}


@aplicacion.post('/comparar')
def comparar(solicitud: SolicitudMetrologia) -> dict:
    carpeta = RAIZ / 'metrologia' / str(solicitud.comparacion_identificador)
    try:
        return procesar_carpeta(carpeta)
    except (ValueError, OSError, KeyError, IndexError) as error:
        raise HTTPException(422, str(error)[:1200]) from error
